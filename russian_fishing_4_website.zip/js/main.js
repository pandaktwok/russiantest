// Funcionalidades do menu suspenso e navegação
document.addEventListener('DOMContentLoaded', function() {
    // Inicialização dos menus suspensos
    const dropdowns = document.querySelectorAll('.dropdown');
    
    // Inicialização das abas
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove a classe active de todos os botões e conteúdos
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Adiciona a classe active ao botão clicado e ao conteúdo correspondente
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Função para filtrar peixes
    const searchInput = document.getElementById('search-fish');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const fishCards = document.querySelectorAll('.fish-card');
            
            fishCards.forEach(card => {
                const fishName = card.querySelector('h3').textContent.toLowerCase();
                if (fishName.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // Inicialização do filtro por local
    const locationFilter = document.getElementById('location-filter');
    if (locationFilter) {
        locationFilter.addEventListener('change', function() {
            const selectedLocation = this.value;
            const fishCards = document.querySelectorAll('.fish-card');
            
            fishCards.forEach(card => {
                if (selectedLocation === 'all') {
                    card.style.display = 'block';
                } else {
                    const fishLocations = card.getAttribute('data-locations').split(',');
                    if (fishLocations.includes(selectedLocation)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    }
    
    // Carregamento dinâmico de conteúdo para páginas de peixes
    const fishLinks = document.querySelectorAll('.fish-link');
    fishLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const fishId = this.getAttribute('data-fish-id');
            loadFishDetails(fishId);
        });
    });
    
    // Função para carregar detalhes do peixe
    function loadFishDetails(fishId) {
        // Simulação de carregamento de dados
        // Em uma implementação real, isso poderia ser uma chamada AJAX
        const contentArea = document.getElementById('fish-details');
        contentArea.innerHTML = '<div class="loading">Carregando...</div>';
        
        // Redireciona para a página de detalhes do peixe
        window.location.href = `fish-details.html?id=${fishId}`;
    }
    
    // Carregamento de detalhes do peixe na página de detalhes
    const urlParams = new URLSearchParams(window.location.search);
    const fishId = urlParams.get('id');
    if (fishId && document.getElementById('fish-detail-container')) {
        // Carrega os detalhes do peixe específico
        loadFishDetailContent(fishId);
    }
    
    // Função para carregar o conteúdo detalhado do peixe
    function loadFishDetailContent(fishId) {
        // Em uma implementação real, isso seria uma chamada AJAX ou carregamento de dados
        // Aqui estamos simulando o carregamento
        const detailContainer = document.getElementById('fish-detail-container');
        detailContainer.innerHTML = '<div class="loading">Carregando detalhes...</div>';
        
        // Simulação de tempo de carregamento
        setTimeout(() => {
            // Aqui carregaríamos o conteúdo real
            // Por enquanto, apenas um placeholder
            detailContainer.innerHTML = `
                <div class="fish-header">
                    <img src="images/fish/${fishId}.jpg" alt="Imagem do peixe" class="fish-image">
                    <div class="fish-info">
                        <h2>Nome do Peixe (${fishId})</h2>
                        <p>Informações detalhadas sobre este peixe estariam aqui.</p>
                    </div>
                </div>
                
                <div class="tabs">
                    <button class="tab-button active" data-tab="tab-overview">Visão Geral</button>
                    <button class="tab-button" data-tab="tab-locations">Locais</button>
                    <button class="tab-button" data-tab="tab-equipment">Equipamentos</button>
                    <button class="tab-button" data-tab="tab-techniques">Técnicas</button>
                </div>
                
                <div id="tab-overview" class="tab-content active">
                    <h3>Visão Geral</h3>
                    <p>Informações gerais sobre o peixe, habitat, comportamento, etc.</p>
                </div>
                
                <div id="tab-locations" class="tab-content">
                    <h3>Melhores Locais</h3>
                    <div class="map-container">
                        <div class="map">
                            <!-- Aqui entraria um mapa interativo -->
                        </div>
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Local</th>
                                    <th>Probabilidade</th>
                                    <th>Melhor Período</th>
                                    <th>Pontos Específicos</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Local 1</td>
                                    <td>Alta</td>
                                    <td>Manhã/Entardecer</td>
                                    <td>Próximo à vegetação</td>
                                </tr>
                                <tr>
                                    <td>Local 2</td>
                                    <td>Média</td>
                                    <td>Noite</td>
                                    <td>Águas profundas</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div id="tab-equipment" class="tab-content">
                    <h3>Equipamentos Recomendados</h3>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tipo</th>
                                    <th>Recomendação</th>
                                    <th>Alternativa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Vara</td>
                                    <td>Tipo específico</td>
                                    <td>Alternativa</td>
                                </tr>
                                <tr>
                                    <td>Molinete</td>
                                    <td>Tipo específico</td>
                                    <td>Alternativa</td>
                                </tr>
                                <tr>
                                    <td>Linha</td>
                                    <td>Tipo específico</td>
                                    <td>Alternativa</td>
                                </tr>
                                <tr>
                                    <td>Anzol</td>
                                    <td>Tipo específico</td>
                                    <td>Alternativa</td>
                                </tr>
                                <tr>
                                    <td>Isca</td>
                                    <td>Tipo específico</td>
                                    <td>Alternativa</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div id="tab-techniques" class="tab-content">
                    <h3>Técnicas de Pesca</h3>
                    <div class="technique-cards">
                        <div class="card">
                            <div class="card-content">
                                <h3>Técnica Principal</h3>
                                <p>Descrição detalhada da técnica principal para pescar esta espécie.</p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-content">
                                <h3>Técnica Alternativa</h3>
                                <p>Descrição detalhada da técnica alternativa para pescar esta espécie.</p>
                            </div>
                        </div>
                    </div>
                    <div class="tips-section">
                        <h3>Dicas Especiais</h3>
                        <ul>
                            <li>Dica específica para esta espécie</li>
                            <li>Outra dica importante</li>
                            <li>Considerações sobre condições climáticas</li>
                        </ul>
                    </div>
                </div>
            `;
            
            // Reinicializa as abas na página de detalhes
            const detailTabButtons = document.querySelectorAll('.tab-button');
            const detailTabContents = document.querySelectorAll('.tab-content');
            
            detailTabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    detailTabButtons.forEach(btn => btn.classList.remove('active'));
                    detailTabContents.forEach(content => content.classList.remove('active'));
                    
                    button.classList.add('active');
                    const tabId = button.getAttribute('data-tab');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        }, 500);
    }
});
