# Tabela Comparativa: Espécies de Peixes por Local

Esta tabela mostra a distribuição das principais espécies de peixes nos diferentes locais do Russian Fishing 4.

| Espécie | Mosquito Lake | Winding Rivulet | Old Burg Lake | Belaya River | Kuori Lake | Bear Lake | Volkhov River | Copper Lake | Lower Tunguska | Akhtuba River |
|---------|:-------------:|:---------------:|:-------------:|:------------:|:----------:|:---------:|:-------------:|:-----------:|:--------------:|:-------------:|
| **Crucian Carp** | ✓ |   |   |   |   |   |   | ✓ |   | ✓ |
| **Common Roach** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |
| **Rudd** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |
| **Tench** | ✓ |   | ✓ |   | ✓ | ✓ |   |   |   |   |
| **Grass Carp** | ✓ |   |   |   |   |   |   | ✓ |   | ✓ |
| **Common Carp** | ✓ |   | ✓ |   | ✓ | ✓ |   |   |   |   |
| **Mirror Carp** | ✓ |   | ✓ |   | ✓ | ✓ |   |   |   |   |
| **Wild Carp** |   |   |   |   |   |   |   | ✓ |   | ✓ |
| **Perch** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |
| **Pike** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |
| **Zander** |   | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |
| **Bream** | ✓ |   | ✓ |   | ✓ | ✓ |   |   |   |   |
| **Eastern Bream** |   |   |   |   |   |   |   | ✓ |   | ✓ |
| **Chub** |   | ✓ |   | ✓ |   |   | ✓ |   |   |   |
| **Ide** |   | ✓ |   | ✓ |   |   | ✓ |   |   |   |
| **Barbel** |   | ✓ |   | ✓ |   |   | ✓ |   |   |   |
| **Asp** |   |   |   | ✓ |   |   | ✓ |   |   |   |
| **Catfish** |   |   |   | ✓ |   |   | ✓ |   |   | ✓ |
| **Northern Pike** |   |   |   |   | ✓ |   |   |   |   |   |
| **Lake Trout** |   |   |   |   | ✓ | ✓ |   |   |   |   |
| **Arctic Char** |   |   |   |   |   | ✓ |   |   |   |   |
| **Sterlet** |   |   |   |   |   |   | ✓ |   |   | ✓ |
| **Beluga Sturgeon** |   |   |   |   |   |   | ✓ |   |   | ✓ |
| **Taimen** |   |   |   |   |   |   |   |   | ✓ |   |
| **Lenok** |   |   |   |   |   |   |   |   | ✓ |   |
| **Arctic Grayling** |   |   |   |   |   |   |   |   | ✓ |   |
| **Siberian Sturgeon** |   |   |   |   |   |   |   |   | ✓ |   |

Legenda:
- ✓: Espécie presente no local
- Espaço em branco: Espécie não encontrada no local

Esta tabela ajuda a identificar rapidamente onde encontrar cada espécie de peixe no jogo, facilitando o planejamento das sessões de pesca conforme o objetivo do jogador.
