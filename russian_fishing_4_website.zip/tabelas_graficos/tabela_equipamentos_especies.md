# Tabela Comparativa: Equipamentos Recomendados por Espécie

Esta tabela mostra os equipamentos mais adequados para a pesca de cada espécie no Russian Fishing 4.

| Espécie | Tipo de Vara | Molinete Recomendado | Linha | Anzol | Isca/Técnica Recomendada |
|---------|-------------|---------------------|-------|-------|--------------------------|
| **Crucian Carp** | Float Rod (2-3m) | Light Float Reel | Mono 0.16-0.18mm | Small Hook (#12-14) | Worm, Maggot, Bread |
| **Common Roach** | Match Rod (3-4m) | Light Float Reel | Mono 0.14-0.16mm | Small Hook (#14-16) | Maggot, Bloodworm, Bread |
| **Rudd** | Match Rod (3-4m) | Light Float Reel | Mono 0.14-0.16mm | Small Hook (#14-16) | Maggot, Worm, Bread |
| **Tench** | Medium Feeder Rod | Medium Feeder Reel | Mono 0.20-0.22mm | Medium Hook (#10-12) | Worm, Corn, Boilies |
| **Grass Carp** | Heavy Feeder Rod | Heavy Feeder Reel | Mono 0.25-0.30mm | Medium Hook (#8-10) | Corn, Grass, Boilies |
| **Common Carp** | Carp Rod | Carp Reel | Mono 0.28-0.35mm | Carp Hook (#6-8) | Boilies, Corn, Pellets |
| **Mirror Carp** | Carp Rod | Carp Reel | Mono 0.28-0.35mm | Carp Hook (#6-8) | Boilies, Corn, Pellets |
| **Wild Carp** | Medium Feeder Rod | Medium Feeder Reel | Mono 0.22-0.25mm | Medium Hook (#8-10) | Cream Corn, Boilies |
| **Perch** | Light Spinning Rod | Light Spinning Reel | Braided 0.10-0.14mm | Small Treble Hook | Spinner, Soft Plastic |
| **Pike** | Medium Spinning Rod | Medium Spinning Reel | Braided 0.16-0.20mm | Medium Treble Hook | Spoon, Crankbait, Jerkbait |
| **Zander** | Medium Spinning Rod | Medium Spinning Reel | Braided 0.14-0.18mm | Medium Treble Hook | Jig, Soft Plastic |
| **Bream** | Medium Feeder Rod | Medium Feeder Reel | Mono 0.18-0.22mm | Medium Hook (#10-12) | Worm, Maggot, Method Feeder |
| **Eastern Bream** | Medium Feeder Rod | Medium Feeder Reel | Mono 0.18-0.22mm | Medium Hook (#10-12) | Worm, Maggot, Method Feeder |
| **Chub** | Medium Spinning Rod | Medium Spinning Reel | Mono 0.20-0.22mm | Medium Hook (#8-10) | Grasshopper, Bread, Small Spinner |
| **Ide** | Medium Float Rod | Medium Float Reel | Mono 0.18-0.20mm | Medium Hook (#10-12) | Worm, Maggot, Bread |
| **Barbel** | Heavy Feeder Rod | Heavy Feeder Reel | Mono 0.22-0.25mm | Medium Hook (#8-10) | Worm, Pellets, Boilies |
| **Asp** | Medium Spinning Rod | Medium Spinning Reel | Braided 0.14-0.18mm | Medium Treble Hook | Spinner, Spoon, Small Fish |
| **Catfish** | Catfish Rod | Big Pit Reel | Braided 0.30-0.40mm | Catfish Hook (#1-2/0) | Live Bait, Large Boilies |
| **Northern Pike** | Heavy Spinning Rod | Heavy Spinning Reel | Braided 0.20-0.25mm | Large Treble Hook | Large Spoon, Jerkbait |
| **Lake Trout** | Medium Spinning Rod | Medium Spinning Reel | Mono 0.20-0.22mm | Medium Hook (#6-8) | Spinner, Spoon, Minnow |
| **Arctic Char** | Medium Spinning Rod | Medium Spinning Reel | Mono 0.18-0.20mm | Medium Hook (#8-10) | Spinner, Spoon, Fly |
| **Sterlet** | Heavy Feeder Rod | Heavy Feeder Reel | Braided 0.25-0.30mm | Medium Hook (#4-6) | Worm, Bloodworm, Crayfish |
| **Beluga Sturgeon** | Sturgeon Rod | Big Pit Reel | Braided 0.35-0.45mm | Sturgeon Hook (#1/0-3/0) | Large Worm, Crayfish, Cutbait |
| **Taimen** | Extra Heavy Spinning Rod | Extra Heavy Spinning Reel | Braided 0.30-0.40mm | Large Treble Hook | Large Spoon, Large Minnow |
| **Lenok** | Medium Spinning Rod | Medium Spinning Reel | Mono 0.20-0.22mm | Medium Hook (#6-8) | Spinner, Spoon, Fly |
| **Arctic Grayling** | Light Spinning Rod | Light Spinning Reel | Mono 0.16-0.18mm | Small Hook (#10-12) | Small Spinner, Fly |
| **Siberian Sturgeon** | Sturgeon Rod | Big Pit Reel | Braided 0.30-0.40mm | Sturgeon Hook (#1/0-2/0) | Worm, Crayfish, Cutbait |

Esta tabela ajuda a escolher rapidamente o equipamento mais adequado para cada espécie de peixe no jogo, aumentando as chances de sucesso na captura.
