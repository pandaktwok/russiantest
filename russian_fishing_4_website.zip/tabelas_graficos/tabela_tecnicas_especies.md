# Tabela Comparativa: Técnicas de Pesca por Espécie e Local

Esta tabela mostra as técnicas de pesca mais eficazes para cada espécie de peixe, considerando os locais onde são encontradas no Russian Fishing 4.

| Espécie | Técnica Principal | Técnica Alternativa | Melhor Período | Melhores Locais | Dicas Especiais |
|---------|------------------|---------------------|----------------|-----------------|-----------------|
| **Crucian Carp** | Float Fishing | Method Feeder | Manhã/Entardecer | Mosquito Lake, Copper Lake | Pescar próximo à vegetação aquática |
| **Common Roach** | Match Fishing | Light Feeder | Dia | Todos os lagos e rios | Usar iscas pequenas e anzóis finos |
| **Rudd** | Float Fishing | Match Fishing | Dia | Águas rasas com vegetação | Pescar na camada superior da água |
| **Tench** | Method Feeder | Float Fishing | Madrugada/Noite | Mosquito Lake, Old Burg Lake | Usar groundbait com sementes |
| **Grass Carp** | Method Feeder | Float Fishing | Meio-dia (dias quentes) | Mosquito Lake, Copper Lake | Usar milho e boilies vegetais |
| **Common Carp** | Hair Rig | Method Feeder | Entardecer/Noite | Old Burg Lake, Bear Lake | Usar PVA bags com pellets |
| **Mirror Carp** | Hair Rig | Method Feeder | Entardecer/Noite | Old Burg Lake, Bear Lake | Usar boilies de frutas ou peixes |
| **Wild Carp** | Method Feeder | Float Fishing | Madrugada/Entardecer | Copper Lake (ponto 67:57) | Usar Cream Corn como isca |
| **Perch** | Jigging | Spinner Retrieve | Manhã/Entardecer | Margens com estruturas | Usar iscas que imitam pequenos peixes |
| **Pike** | Jerkbait | Spinner Retrieve | Manhã | Águas abertas próximas à vegetação | Usar leader de aço |
| **Zander** | Jigging | Vertical Jigging | Entardecer/Noite | Áreas profundas | Movimentos lentos com a isca |
| **Bream** | Feeder | Method Feeder | Madrugada | Old Burg Lake, Kuori Lake | Usar groundbait com partículas pequenas |
| **Eastern Bream** | Feeder | Method Feeder | Noite | Copper Lake, Akhtuba River | Usar worms e maggots como isca |
| **Chub** | Float Fishing | Light Spinning | Dia | Corredeiras em rios | Usar iscas superficiais |
| **Ide** | Float Fishing | Light Spinning | Dia | Áreas médias dos rios | Pescar na meia-água |
| **Barbel** | Heavy Feeder | Bottom Fishing | Noite | Áreas de correnteza | Usar pellets e boilies |
| **Asp** | Spinning | Surface Lures | Manhã | Belaya River, Volkhov River | Lançamentos longos e recolhimento rápido |
| **Catfish** | Heavy Bottom Fishing | Live Bait | Noite | Poços profundos | Usar iscas grandes e equipamento resistente |
| **Northern Pike** | Heavy Spinning | Trolling | Manhã | Kuori Lake | Usar iscas grandes e coloridas |
| **Lake Trout** | Spinning | Trolling | Manhã/Entardecer | Áreas profundas de lagos | Pescar em diferentes profundidades |
| **Arctic Char** | Spinning | Float Fishing | Manhã | Bear Lake | Usar iscas que imitam insetos |
| **Sterlet** | Heavy Feeder | Bottom Fishing | Noite | Volkhov River, Akhtuba River | Usar worms e crayfish |
| **Beluga Sturgeon** | Heavy Bottom Fishing | Heavy Feeder | Noite | Volkhov River, Akhtuba River | Usar cutbait e equipamento extra resistente |
| **Taimen** | Heavy Spinning | Trolling | Manhã/Entardecer | Lower Tunguska River | Usar iscas grandes que imitam peixes |
| **Lenok** | Spinning | Float Fishing | Dia | Lower Tunguska River | Usar spinners médios |
| **Arctic Grayling** | Light Spinning | Float Fishing | Dia | Lower Tunguska River | Usar iscas pequenas e leves |
| **Siberian Sturgeon** | Heavy Bottom Fishing | Heavy Feeder | Noite | Lower Tunguska River | Usar worms e crayfish como isca |

Esta tabela ajuda a escolher rapidamente a técnica mais adequada para cada espécie de peixe no jogo, considerando os melhores locais e períodos para aumentar as chances de sucesso na captura.
